# Clip Caption v2 - Auto Captions + Emoji (Hindi / English / Hinglish)

Video upload -> "Add Captions" -> auto speech-to-text captions with emoji,
styles, fonts -> Export.

First use: speech model (~40 MB) internet se ek baar download hota hai, uske baad offline chalta hai.
