package com.example.clipcaption

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Decodes the audio track of a video to 16 kHz mono 16-bit PCM and streams it in chunks. */
object AudioDecoder {

    fun decode(
        context: Context,
        uri: Uri,
        sink: (ByteArray, Int) -> Unit,
        progress: (Int) -> Unit
    ) {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) { track = i; break }
        }
        if (track < 0) {
            extractor.release()
            throw IllegalStateException("Is video me audio nahi hai")
        }
        extractor.selectTrack(track)
        val format = extractor.getTrackFormat(track)
        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

        var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false

        val chunk = ByteArray(8000)
        var chunkLen = 0
        var step = sampleRate / 16000.0
        var inIdx = 0L
        var nextBoundary = step
        var acc = 0L
        var cnt = 0
        var lastPct = -1

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val out = codec.getOutputBuffer(oi)!!
                    if (info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val sb = out.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val total = sb.remaining()
                        val frames = total / channels
                        for (f in 0 until frames) {
                            var sum = 0
                            for (ch in 0 until channels) sum += sb.get(f * channels + ch).toInt()
                            acc += (sum / channels).toLong()
                            cnt++
                            inIdx++
                            if (inIdx >= nextBoundary) {
                                val s = (acc / cnt).toInt()
                                acc = 0L
                                cnt = 0
                                nextBoundary += step
                                chunk[chunkLen++] = (s and 0xFF).toByte()
                                chunk[chunkLen++] = ((s shr 8) and 0xFF).toByte()
                                if (chunkLen >= chunk.size) {
                                    sink(chunk, chunkLen)
                                    chunkLen = 0
                                }
                            }
                        }
                        if (durationUs > 0) {
                            val pct = ((info.presentationTimeUs * 100) / durationUs).toInt().coerceIn(0, 100)
                            if (pct != lastPct && pct % 5 == 0) {
                                lastPct = pct
                                progress(pct)
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    step = sampleRate / 16000.0
                    nextBoundary = inIdx + step
                }
            }
            if (chunkLen > 0) sink(chunk, chunkLen)
        } finally {
            try { codec.stop() } catch (e: Exception) {}
            codec.release()
            extractor.release()
        }
    }
}
