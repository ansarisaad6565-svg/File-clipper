package com.example.clipcaption

/** Devanagari -> Roman (Hinglish) transliteration. */
object Translit {

    private val common = mapOf(
        "है" to "hai", "हैं" to "hain", "में" to "mein", "मैं" to "main", "और" to "aur",
        "क्या" to "kya", "नहीं" to "nahi", "यह" to "yeh", "वह" to "woh", "तो" to "toh",
        "भी" to "bhi", "से" to "se", "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke",
        "कि" to "ki", "ये" to "ye", "वो" to "woh", "हम" to "hum", "आप" to "aap", "तुम" to "tum",
        "मेरा" to "mera", "मेरी" to "meri", "मेरे" to "mere", "तेरा" to "tera", "उसका" to "uska",
        "था" to "tha", "थी" to "thi", "थे" to "the", "हो" to "ho", "होगा" to "hoga",
        "कर" to "kar", "करो" to "karo", "करना" to "karna", "करते" to "karte", "जो" to "jo",
        "ही" to "hi", "पर" to "par", "एक" to "ek", "दो" to "do", "बहुत" to "bahut",
        "अच्छा" to "accha", "कैसे" to "kaise", "कैसा" to "kaisa", "क्यों" to "kyun",
        "लेकिन" to "lekin", "अब" to "ab", "जब" to "jab", "तब" to "tab", "यहाँ" to "yahan",
        "वहाँ" to "wahan", "दोस्तों" to "dosto", "वीडियो" to "video", "चैनल" to "channel",
        "सब्सक्राइब" to "subscribe", "लाइक" to "like", "शेयर" to "share", "ओके" to "okay"
    )

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v",
        'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h", 'ळ' to "l"
    )

    private val indep = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
        'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
    )

    private val matra = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'े' to "e",
        'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ृ' to "ri", 'ॉ' to "o", 'ॅ' to "e"
    )

    private class Syl(var c: String, var v: String?) {
        var halant = false
        var nasal = ""
    }

    fun toRoman(word: String): String {
        common[word]?.let { return it }
        if (word.none { it in '\u0900'..'\u097F' }) return word

        val syls = ArrayList<Syl>()
        for (ch in word) {
            when {
                cons.containsKey(ch) -> syls.add(Syl(cons[ch]!!, null))
                ch == '\u094D' -> syls.lastOrNull()?.halant = true
                matra.containsKey(ch) -> {
                    val last = syls.lastOrNull()
                    if (last != null) { last.v = matra[ch]; last.halant = false }
                }
                indep.containsKey(ch) -> syls.add(Syl("", indep[ch]!!))
                ch == '\u0902' || ch == '\u0901' -> syls.lastOrNull()?.nasal = "n"
                ch == '\u0903' -> syls.lastOrNull()?.nasal = "h"
                ch == '\u093C' -> { /* nukta: ignore */ }
                else -> syls.add(Syl(ch.toString(), ""))
            }
        }

        val n = syls.size
        val keep = BooleanArray(n)
        val sb = StringBuilder()
        for (i in 0 until n) {
            val s = syls[i]
            val v = s.v
            if (v != null) {
                sb.append(s.c).append(v).append(s.nasal)
                keep[i] = v.isNotEmpty()
            } else if (s.halant) {
                sb.append(s.c).append(s.nasal)
                keep[i] = false
            } else {
                val isLast = i == n - 1
                val prevOk = i > 0 && keep[i - 1]
                val nextExplicit = i + 1 < n && !syls[i + 1].v.isNullOrEmpty()
                val delete = isLast || (prevOk && nextExplicit)
                sb.append(s.c)
                if (!delete) sb.append("a")
                sb.append(s.nasal)
                keep[i] = !delete
            }
        }
        return sb.toString()
    }
}
