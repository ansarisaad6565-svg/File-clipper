package com.example.clipcaption

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Draws one caption (stroke, box, glow, word highlight, emoji) into a transparent bitmap. */
class CaptionRenderer(
    private val frameW: Int,
    private val frameH: Int,
    private val style: StyleSpec,
    private val font: Typeface,
    sizeScale: Float
) {
    private val px: Float = min(frameW, frameH) * 0.07f * sizeScale

    fun blank(): Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)

    fun render(words: List<String>, activeIdx: Int, emoji: String): Bitmap {
        if (words.isEmpty()) return blank()

        val shown = words.map { if (style.allCaps) it.uppercase() else it }
        val sb = StringBuilder()
        val ranges = ArrayList<IntArray>()
        shown.forEachIndexed { i, w ->
            if (i > 0) sb.append(' ')
            val s = sb.length
            sb.append(w)
            ranges.add(intArrayOf(s, sb.length))
        }
        if (emoji.isNotEmpty()) sb.append(' ').append(emoji)
        val text = sb.toString()

        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = px
        paint.typeface = font
        paint.strokeJoin = Paint.Join.ROUND

        var pad = (px * 0.4f).toInt()
        if (style.glowColor != 0) pad += (px * 0.4f).toInt()
        pad += (px * style.strokeRatio).toInt()

        val maxTextW = max(100, (frameW * 0.9f).toInt() - 2 * pad)

        val l0 = StaticLayout.Builder.obtain(text, 0, text.length, paint, maxTextW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        var widest = 0f
        for (i in 0 until l0.lineCount) widest = max(widest, l0.getLineWidth(i))
        val layoutW = ceil(widest).toInt() + 2

        fun makeLayout(cs: CharSequence): StaticLayout =
            StaticLayout.Builder.obtain(cs, 0, cs.length, paint, layoutW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.08f)
                .build()

        val plainLayout = makeLayout(text)
        val fillCs: CharSequence =
            if (style.useHighlight && activeIdx in ranges.indices) {
                val sp = SpannableString(text)
                sp.setSpan(
                    ForegroundColorSpan(style.highlightColor),
                    ranges[activeIdx][0], ranges[activeIdx][1],
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                sp
            } else text
        val fillLayout = makeLayout(fillCs)

        val bw = layoutW + 2 * pad
        val bh = plainLayout.height + 2 * pad
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        if (style.boxColor != 0) {
            val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            boxPaint.color = style.boxColor
            val r = px * 0.35f
            c.drawRoundRect(0f, 0f, bw.toFloat(), bh.toFloat(), r, r, boxPaint)
        }

        c.save()
        c.translate(pad.toFloat(), pad.toFloat())

        if (style.strokeRatio > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = px * style.strokeRatio
            paint.color = style.strokeColor
            paint.clearShadowLayer()
            plainLayout.draw(c)
        }

        paint.style = Paint.Style.FILL
        paint.strokeWidth = 0f
        paint.color = style.textColor
        if (style.glowColor != 0) {
            paint.setShadowLayer(px * 0.35f, 0f, 0f, style.glowColor)
        } else if (style.shadow) {
            paint.setShadowLayer(px * 0.08f, 0f, px * 0.04f, 0xCC000000.toInt())
        }
        fillLayout.draw(c)
        c.restore()
        return bmp
    }
}
