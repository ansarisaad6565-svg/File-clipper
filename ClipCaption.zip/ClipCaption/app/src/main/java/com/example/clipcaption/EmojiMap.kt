package com.example.clipcaption

/** Keyword -> emoji (English, Hinglish and Hindi). */
object EmojiMap {

    private const val DATA = """
❤️ love loved loving pyar pyaar prem dil heart ishq mohabbat प्यार प्रेम दिल इश्क मोहब्बत
😍 beautiful beauty pretty cute gorgeous sundar khoobsurat सुंदर खूबसूरत
😂 funny lol haha hahaha joke mazak hasi hansi comedy मज़ाक मजाक हंसी हँसी कॉमेडी
😊 happy khush khushi smile muskan मुस्कान खुश खुशी
😢 sad cry crying dukh udaas rona रोना दुख उदास आंसू
😡 angry anger gussa gusse गुस्सा
😱 shocked shock scary horror darr dar daro डर डरावना
😴 sleep sleeping tired neend sona thaka नींद सोना थका
🤔 think thinking idea soch sochna vichar सोच विचार आइडिया
🔥 fire hot lit aag mast zabardast blast धमाका आग मस्त जबरदस्त
💰 money cash rich paisa paise rupee rupaye dollar salary पैसा पैसे रुपया रुपये धन अमीर
🏠 home house ghar makaan घर मकान
🍕 food pizza khana khaana khane bhook hungry eat eating खाना भूख
☕ tea chai coffee चाय कॉफी
🍔 burger fastfood
🍰 cake birthday mithai मिठाई केक
🎂 bday जन्मदिन
🎉 party celebrate celebration congratulations congrats mubarak badhai जश्न बधाई मुबारक पार्टी
🎵 music song gaana gana gaane songs sing singing गाना संगीत गाने
🎬 movie film cinema video videos vlog फिल्म वीडियो
📱 phone mobile call फोन मोबाइल
💻 computer laptop code coding technology tech लैपटॉप कंप्यूटर
🚗 car drive driving gaadi gadi गाड़ी कार
✈️ flight plane travel trip safar yatra सफर यात्रा
🌍 world duniya earth दुनिया
🌧️ rain barish baarish बारिश
☀️ sun sunny dhoop सूरज धूप
🌙 moon night raat chand रात चाँद चांद
⭐ star stars sitara tara सितारा तारा
🌹 flower flowers rose phool गुलाब फूल
🐶 dog dogs kutta कुत्ता
🐱 cat billi बिल्ली
💪 strong strength gym power workout fitness taakat mehnat ताकत मेहनत जिम
🏆 win winner won victory champion jeet jeetna trophy जीत विजेता
🥇 first number
📚 study book books school education padhai padhna kitab पढ़ाई किताब स्कूल
🎓 college university degree exam exams pariksha परीक्षा
💼 work job office business kaam naukri vyapar काम नौकरी ऑफिस बिज़नेस
⏰ time clock alarm deadline waqt samay समय वक्त
👍 good great nice awesome perfect best excellent accha achha badiya sahi अच्छा बढ़िया सही
👎 bad worst bura बुरा
🙏 please thanks thank dhanyavad shukriya namaste pranam sorry maaf धन्यवाद शुक्रिया नमस्ते माफ
👋 hello hey bye namaskar नमस्कार
🤝 friend friends dost dosto deal help dosti दोस्त दोस्तों दोस्ती मदद
👨‍👩‍👧 family mother father mummy papa parivar maa baap परिवार माँ पापा मम्मी
👶 baby child kid bachcha bachche बच्चा बच्चे
💔 breakup heartbreak broken dhokha धोखा
😎 cool swag style stylish
🤩 amazing wow incredible unbelievable kamaal कमाल
🚀 rocket launch growth fast success safal safalta सफलता तेज
💡 learn tip trick hack sikho seekho सीखो
⚠️ warning danger careful khatra savdhan खतरा सावधान
✅ yes correct right true haan sach हाँ हां सच सही
❌ no wrong false nahi galat नहीं गलत
❓ question why kyun kyon how सवाल
📈 profit increase growth badhna फायदा
📉 loss decrease down nuksan नुकसान
🔔 subscribe subscribed bell channel सब्सक्राइब चैनल
👍🏻 like likes share comment लाइक शेयर कमेंट
🙌 amazing celebrate hurray yay
🧠 brain mind dimaag dimag दिमाग
👀 look watch dekho dekhna see देखो देखना
👂 listen sunno suno sunna सुनो सुनना
🗣️ speak talk bolo bolna baat बोलो बात
😷 sick ill bimar bimari doctor medicine dawai दवाई बीमार बीमारी
🕌 mosque masjid allah eid ramzan मस्जिद अल्लाह ईद
🛕 temple mandir bhagwan god ram krishna shiv मंदिर भगवान राम कृष्ण शिव
🇮🇳 india bharat hindustan भारत इंडिया हिंदुस्तान
🏏 cricket match ipl क्रिकेट मैच
⚽ football soccer goal फुटबॉल
🔫 gun fight ladai लड़ाई
💣 bomb blast boom
👑 king queen raja rani raaja राजा रानी
💎 diamond gold sona hira सोना हीरा
🌟 shine chamak bright चमक
😭 crying roya roi
🥳 surprise
🎁 gift gifts tohfa तोहफा गिफ्ट
🛍️ shopping buy sale shop kharidna खरीदना
🍎 apple fruit fruits phal fal फल सेब
🥗 healthy diet salad
🏖️ beach sea samundar समंदर
⛰️ mountain pahad पहाड़
🌳 tree nature plant ped पेड़ प्रकृति
🔒 lock secret private password raaz राज
🔑 key solution
📸 photo picture camera selfie फोटो तस्वीर कैमरा
🎤 mic podcast interview speech
🧘 yoga meditation peace shanti योग शांति
😅 oops mistake galti गलती
🤗 hug welcome swagat गले स्वागत
"""

    private fun norm(s: String): String {
        var t = s.lowercase().trim()
        t = t.replace("aa", "a").replace("ee", "i").replace("oo", "u")
            .replace("w", "v").replace("ph", "f")
        if (t.length > 3 && t.endsWith("s")) t = t.dropLast(1)
        return t
    }

    private val map: HashMap<String, String> by lazy {
        val m = HashMap<String, String>()
        for (line in DATA.lines()) {
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 2) continue
            val emoji = parts[0]
            for (i in 1 until parts.size) {
                val k = norm(parts[i])
                if (k.length >= 2 && !m.containsKey(k)) m[k] = emoji
            }
        }
        m
    }

    fun find(vararg candidates: String): String? {
        for (c in candidates) {
            val e = map[norm(c)]
            if (e != null) return e
        }
        return null
    }
}
