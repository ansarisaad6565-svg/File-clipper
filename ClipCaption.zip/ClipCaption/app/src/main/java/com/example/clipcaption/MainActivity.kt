package com.example.clipcaption

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var videoUri: Uri? = null
    private var videoW = 1080
    private var videoH = 1920
    private var durationMs = 0L
    private val captions = mutableListOf<Caption>()
    private var busy = false
    private var lastSaved: Uri? = null

    private lateinit var videoView: VideoView
    private lateinit var tvInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ivPreview: ImageView
    private lateinit var llCaptions: LinearLayout
    private lateinit var spLang: Spinner
    private lateinit var spWords: Spinner
    private lateinit var spStyle: Spinner
    private lateinit var spFont: Spinner
    private lateinit var spSize: Spinner
    private lateinit var spPos: Spinner
    private lateinit var cbEmoji: CheckBox
    private lateinit var btnPick: Button
    private lateinit var btnCaption: Button
    private lateinit var btnExport: Button
    private lateinit var btnShare: Button

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        videoView = findViewById(R.id.videoView)
        tvInfo = findViewById(R.id.tvInfo)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)
        ivPreview = findViewById(R.id.ivPreview)
        llCaptions = findViewById(R.id.llCaptions)
        spLang = findViewById(R.id.spLang)
        spWords = findViewById(R.id.spWords)
        spStyle = findViewById(R.id.spStyle)
        spFont = findViewById(R.id.spFont)
        spSize = findViewById(R.id.spSize)
        spPos = findViewById(R.id.spPos)
        cbEmoji = findViewById(R.id.cbEmoji)
        btnPick = findViewById(R.id.btnPick)
        btnCaption = findViewById(R.id.btnCaption)
        btnExport = findViewById(R.id.btnExport)
        btnShare = findViewById(R.id.btnShare)

        setup(spLang, listOf("Hinglish (Roman Hindi)", "Hindi (देवनागरी)", "English"), 0)
        setup(spWords, listOf("1 word", "2 words", "3 words", "4 words", "5 words"), 1)
        setup(spStyle, Presets.styles.map { it.name }, 2)
        setup(spFont, Presets.fonts.map { it.name }, 1)
        setup(spSize, Presets.sizeNames, 1)
        setup(spPos, Presets.positionNames, 0)

        val previewListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spStyle.onItemSelectedListener = previewListener
        spFont.onItemSelectedListener = previewListener
        spSize.onItemSelectedListener = previewListener

        btnPick.setOnClickListener { picker.launch("video/*") }
        btnCaption.setOnClickListener { addCaptions() }
        btnExport.setOnClickListener { export() }
        btnShare.setOnClickListener { share() }
        updatePreview()
    }

    private fun setup(sp: Spinner, items: List<String>, sel: Int) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
    }

    private fun ui(block: () -> Unit) = runOnUiThread(block)

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun setBusy(b: Boolean) {
        busy = b
        btnPick.isEnabled = !b
        btnCaption.isEnabled = !b
        btnExport.isEnabled = !b
    }

    // ---------- video ----------

    private fun loadVideo(uri: Uri) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) { videoW = h; videoH = w } else { videoW = w; videoH = h }
        } catch (e: Exception) {
            toast("Video read nahi ho paya: ${e.message}")
            return
        }
        videoUri = uri
        captions.clear()
        refreshList()
        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { it.isLooping = true; videoView.start() }
        tvInfo.text = "Video: ${durationMs / 1000} sec  (${videoW}x${videoH})"
        tvStatus.text = "Ab 'Add Captions' dabao."
        btnShare.isEnabled = false
        updatePreview()
    }

    // ---------- auto captions ----------

    private fun addCaptions() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (busy) return
        setBusy(true)
        progress.isIndeterminate = true

        val langPos = spLang.selectedItemPosition
        val modelCode = if (langPos == 2) "en" else "hi"
        val langKey = when (langPos) { 0 -> "hinglish"; 1 -> "hi"; else -> "en" }
        val perCap = spWords.selectedItemPosition + 1

        thread {
            try {
                val path = ModelManager.ensure(this, modelCode) { m -> ui { tvStatus.text = m } }
                ui { tvStatus.text = "Speech model load ho raha hai..." }
                val raw = Transcriber.run(this, uri, path) { m -> ui { tvStatus.text = m } }
                if (raw.isEmpty()) {
                    ui { tvStatus.text = "Koi speech nahi mili. Dusri language try karo." }
                } else {
                    val caps = CaptionBuilder.build(raw, langKey, perCap, true)
                    ui {
                        captions.clear()
                        captions.addAll(caps)
                        refreshList()
                        tvStatus.text = "${caps.size} captions ban gaye! Style chuno, fir Export dabao."
                    }
                }
            } catch (t: Throwable) {
                ui { tvStatus.text = "Error: ${t.message ?: t.javaClass.simpleName}" }
            } finally {
                ui { progress.isIndeterminate = false; setBusy(false) }
            }
        }
    }

    private fun refreshList() {
        llCaptions.removeAllViews()
        if (captions.isEmpty()) {
            llCaptions.addView(TextView(this).apply { text = "Abhi koi caption nahi" })
            return
        }
        for (cap in captions) {
            val tv = TextView(this)
            tv.text = "${fmt(cap.startMs)}   ${cap.text} ${cap.emoji}"
            tv.textSize = 16f
            tv.setPadding(0, 14, 0, 14)
            tv.setOnClickListener { editDialog(cap) }
            llCaptions.addView(tv)
        }
    }

    private fun editDialog(cap: Caption) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(48, 16, 48, 0)
        val etText = EditText(this)
        etText.setText(cap.text)
        etText.hint = "Caption text"
        val etEmoji = EditText(this)
        etEmoji.setText(cap.emoji)
        etEmoji.hint = "Emoji (khali = nahi)"
        box.addView(etText)
        box.addView(etEmoji)
        AlertDialog.Builder(this)
            .setTitle("Caption edit")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                cap.setText(etText.text.toString())
                cap.emoji = etEmoji.text.toString().trim()
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- style preview ----------

    private fun makeRenderer(): CaptionRenderer = CaptionRenderer(
        videoW, videoH,
        Presets.styles[spStyle.selectedItemPosition],
        Presets.fonts[spFont.selectedItemPosition].typeface(),
        Presets.sizeScales[spSize.selectedItemPosition]
    )

    private fun updatePreview() {
        if (!::spStyle.isInitialized || !::ivPreview.isInitialized) return
        try {
            val cap = makeRenderer().render(listOf("Ye", "caption", "aise", "dikhega"), 1, "🔥")
            val w = videoW
            val h = (cap.height * 2.2f).toInt().coerceAtLeast(160)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint()
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF455A64.toInt(), 0xFF1B1B1B.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.drawBitmap(cap, (w - cap.width) / 2f, (h - cap.height) / 2f, null)
            ivPreview.setImageBitmap(out)
        } catch (e: Exception) {
            // preview is optional
        }
    }

    // ---------- export ----------

    private fun export() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (captions.isEmpty()) { toast("Pehle 'Add Captions' dabao"); return }
        if (busy) return

        val style = Presets.styles[spStyle.selectedItemPosition]
        val overlay = CaptionBitmapOverlay(
            captions.toList(), makeRenderer(), cbEmoji.isChecked,
            spPos.selectedItemPosition, style.useHighlight
        )
        val effects: List<Effect> = listOf(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            .setEffects(Effects(emptyList(), effects))
            .build()

        val outFile = File(cacheDir, "cc_${System.currentTimeMillis()}.mp4")
        setBusy(true)
        progress.progress = 0
        tvStatus.text = "Export ho raha hai..."

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poller)
                    progress.progress = 100
                    tvStatus.text = "Gallery me save ho raha hai..."
                    saveToGallery(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poller)
                    setBusy(false)
                    tvStatus.text = "Export error: ${exportException.message}"
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        handler.post(poller)
    }

    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                progress.progress = holder.progress
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun saveToGallery(file: File) {
        thread {
            var saved: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "ClipCaption_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClipCaption")
                }
                saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (saved != null) {
                    contentResolver.openOutputStream(saved)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    }
                }
                file.delete()
            } catch (e: Exception) {
                ui { tvStatus.text = "Save error: ${e.message}"; setBusy(false) }
                return@thread
            }
            ui {
                setBusy(false)
                lastSaved = saved
                btnShare.isEnabled = saved != null
                tvStatus.text = "Ho gaya! Movies/ClipCaption folder me save hua."
                if (saved != null) {
                    videoView.setVideoURI(saved)
                    videoView.start()
                }
            }
        }
    }

    private fun share() {
        val u = lastSaved ?: return
        val i = Intent(Intent.ACTION_SEND)
        i.type = "video/mp4"
        i.putExtra(Intent.EXTRA_STREAM, u)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share video"))
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        transformer?.cancel()
        super.onDestroy()
    }
}
