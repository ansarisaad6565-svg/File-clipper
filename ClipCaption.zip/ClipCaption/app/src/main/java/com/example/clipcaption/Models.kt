package com.example.clipcaption

import android.graphics.Color
import android.graphics.Typeface

data class RawWord(val text: String, val startMs: Long, val endMs: Long)

data class Word(val text: String, val startMs: Long, val endMs: Long)

class Caption(var words: List<Word>, var emoji: String, var startMs: Long, var endMs: Long) {
    val text: String get() = words.joinToString(" ") { it.text }

    /** Replace the text; word timings are spread evenly over the caption duration. */
    fun setText(t: String) {
        val parts = t.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val dur = (endMs - startMs).coerceAtLeast(parts.size * 100L)
        val step = dur / parts.size
        words = parts.mapIndexed { i, p -> Word(p, startMs + i * step, startMs + (i + 1) * step) }
    }
}

data class StyleSpec(
    val name: String,
    val textColor: Int,
    val strokeColor: Int,
    val strokeRatio: Float,
    val boxColor: Int,
    val useHighlight: Boolean,
    val highlightColor: Int,
    val shadow: Boolean,
    val glowColor: Int,
    val allCaps: Boolean
)

data class FontSpec(val name: String, val family: String, val style: Int) {
    fun typeface(): Typeface = Typeface.create(family, style)
}

object Presets {
    val styles = listOf(
        StyleSpec("Classic Box", Color.WHITE, 0, 0f, 0xB3000000.toInt(), false, 0, false, 0, false),
        StyleSpec("Yellow Pop", 0xFFFFD400.toInt(), Color.BLACK, 0.14f, 0, false, 0, true, 0, true),
        StyleSpec("Karaoke Highlight", Color.WHITE, Color.BLACK, 0.14f, 0, true, 0xFFFFE600.toInt(), true, 0, true),
        StyleSpec("Green Highlight", Color.WHITE, Color.BLACK, 0.14f, 0, true, 0xFF00E676.toInt(), true, 0, true),
        StyleSpec("Neon Glow", 0xFFE0FFFF.toInt(), 0, 0f, 0, false, 0, false, 0xFF00E5FF.toInt(), false),
        StyleSpec("Red Box Bold", Color.WHITE, 0, 0f, 0xFFE53935.toInt(), false, 0, false, 0, true),
        StyleSpec("Comic Red Outline", Color.WHITE, 0xFFD50000.toInt(), 0.18f, 0, false, 0, true, 0, true),
        StyleSpec("Minimal Shadow", Color.WHITE, 0, 0f, 0, false, 0, true, 0, false)
    )

    val fonts = listOf(
        FontSpec("Modern", "sans-serif-medium", Typeface.NORMAL),
        FontSpec("Heavy Bold", "sans-serif-black", Typeface.NORMAL),
        FontSpec("Condensed", "sans-serif-condensed", Typeface.BOLD),
        FontSpec("Classic Serif", "serif", Typeface.BOLD),
        FontSpec("Handwriting", "cursive", Typeface.BOLD),
        FontSpec("Casual", "casual", Typeface.NORMAL),
        FontSpec("Typewriter", "monospace", Typeface.BOLD),
        FontSpec("Light", "sans-serif-light", Typeface.NORMAL)
    )

    val sizeNames = listOf("Chhota", "Medium", "Bada", "Bahut bada")
    val sizeScales = listOf(0.8f, 1.0f, 1.25f, 1.5f)
    val positionNames = listOf("Neeche (Bottom)", "Beech me (Middle)", "Upar (Top)")
}
