package com.example.clipcaption

object CaptionBuilder {

    /** lang: "hi" (Devanagari), "en" (English) or "hinglish" (Roman Hindi). */
    fun build(raw: List<RawWord>, lang: String, perCap: Int, emojiOn: Boolean): MutableList<Caption> {
        val groups = ArrayList<MutableList<RawWord>>()
        var cur = ArrayList<RawWord>()
        for (w in raw) {
            if (cur.isNotEmpty() && (cur.size >= perCap || w.startMs - cur.last().endMs > 700)) {
                groups.add(cur)
                cur = ArrayList()
            }
            cur.add(w)
        }
        if (cur.isNotEmpty()) groups.add(cur)

        val result = ArrayList<Caption>()
        var prevEmoji = ""
        for ((gi, g) in groups.withIndex()) {
            val words = g.map { rw ->
                val shown = if (lang == "hinglish") Translit.toRoman(rw.text) else rw.text
                Word(shown, rw.startMs, rw.endMs)
            }
            var emoji = ""
            if (emojiOn) {
                for ((i, rw) in g.withIndex()) {
                    val e = EmojiMap.find(rw.text, words[i].text)
                    if (e != null) { emoji = e; break }
                }
                if (emoji == prevEmoji) emoji = "" else if (emoji.isNotEmpty()) prevEmoji = emoji
            }
            val start = g.first().startMs
            var end = g.last().endMs + 150
            if (gi + 1 < groups.size) {
                val nextStart = groups[gi + 1].first().startMs
                if (end > nextStart) end = nextStart
            }
            if (end - start < 250) end = start + 250
            result.add(Caption(words, emoji, start, end))
        }
        return result
    }
}
